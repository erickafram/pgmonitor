<?php
$servername = "localhost";
$username = "root";
$password = "NN.C6cqrZZzm";
$dbname = "pgmonitor";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}
?>