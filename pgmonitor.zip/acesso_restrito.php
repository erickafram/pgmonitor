<!DOCTYPE html>
<html>
<head>
    <title>Acesso Restrito</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1>Acesso Restrito</h1>
    <p>Você não tem permissão para acessar esta página.</p>
    <a href="index.php" class="btn btn-primary">Voltar para a página inicial</a>
</div>
</body>
</html>
